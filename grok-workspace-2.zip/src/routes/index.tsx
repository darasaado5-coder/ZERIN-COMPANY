import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";

export const Route = createFileRoute("/")({ component: Home });

const PHONE_DISPLAY = "+964 750 211 5209";
const PHONE_TEL = "+9647502115209";
const WHATSAPP =
  "https://wa.me/9647502115209?text=" +
  encodeURIComponent("السلام عليكم، أرغب بالاستفسار عن خدمات شركة زيرين");
const FACEBOOK = "https://www.facebook.com/share/1CFPsbcoCx/";

function Home() {
  const [open, setOpen] = useState(true);
  const [menu, setMenu] = useState(false);
  const [toast, setToast] = useState("");

  useEffect(() => {
    if (!toast) return;
    const id = window.setTimeout(() => setToast(""), 2200);
    return () => window.clearTimeout(id);
  }, [toast]);

  async function copyPhone() {
    try {
      await navigator.clipboard.writeText(PHONE_DISPLAY);
      setToast("تم نسخ الرقم");
    } catch {
      setToast(PHONE_DISPLAY);
    }
    setMenu(false);
  }

  return (
    <main>
      <img className="kitchen" src="/kitchen.jpg" alt="" />
      <div className="veil" />
      <div className="stage">
        <header className="topbar">
          <div className="top-actions">
            <button
              type="button"
              className="icon-btn"
              aria-label="المزيد"
              aria-expanded={menu}
              onClick={() => setMenu((v) => !v)}
            >
              <DotsIcon />
            </button>
            <a className="icon-btn" href={WHATSAPP} target="_blank" rel="noreferrer" aria-label="واتساب">
              <ChatIcon />
            </a>
            {menu ? (
              <div className="menu" role="menu">
                <a className="menu-item" role="menuitem" href={`tel:${PHONE_TEL}`}>
                  اتصال مباشر
                </a>
                <button type="button" className="menu-item" role="menuitem" onClick={copyPhone}>
                  نسخ الرقم
                </button>
                <a className="menu-item" role="menuitem" href={WHATSAPP} target="_blank" rel="noreferrer">
                  واتساب
                </a>
              </div>
            ) : null}
          </div>
          <h1 className="topbar-title">تواصل معنا</h1>
          <button
            type="button"
            className="icon-btn"
            aria-label={open ? "إغلاق" : "فتح"}
            onClick={() => {
              setOpen((v) => !v);
              setMenu(false);
            }}
          >
            {open ? <CloseIcon /> : <ChatIcon />}
          </button>
        </header>

        {toast ? (
          <p className="toast" role="status">
            {toast}
          </p>
        ) : null}

        <div className="brand">
          <p className="brand-word">ZERIN</p>
          <div className="brand-rule" aria-hidden="true">
            <span />
            <i />
            <span />
          </div>
          <p className="brand-sub">COMPANY</p>
        </div>

        {open ? (
          <section className="sheet sheet-in" aria-label="طرق التواصل">
            <p className="lead">نقدم لكم أفضل الخدمات بجودة عالية</p>
            <h2 className="ask">تواصل معنا</h2>
            <p className="hint">اختر الطريقة الأنسب لك</p>
            <a className="contact-btn wa" href={WHATSAPP} target="_blank" rel="noreferrer">
              <span className="wa-copy">
                <span className="btn-title">تواصل عبر واتساب</span>
                <span className="btn-num" dir="ltr">
                  {PHONE_DISPLAY}
                </span>
              </span>
              <WhatsAppIcon />
            </a>
            <a className="contact-btn fb" href={FACEBOOK} target="_blank" rel="noreferrer">
              <span className="fb-copy">
                <span className="btn-title">زيارة صفحتنا على فيسبوك</span>
              </span>
              <FacebookIcon />
            </a>
          </section>
        ) : (
          <button type="button" className="reopen" onClick={() => setOpen(true)}>
            تواصل معنا
          </button>
        )}
      </div>
    </main>
  );
}

function DotsIcon() {
  return (
    <svg width="18" height="18" viewBox="0 0 18 18" aria-hidden="true">
      <circle cx="9" cy="3.2" r="1.45" fill="currentColor" />
      <circle cx="9" cy="9" r="1.45" fill="currentColor" />
      <circle cx="9" cy="14.8" r="1.45" fill="currentColor" />
    </svg>
  );
}

function ChatIcon() {
  return (
    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" aria-hidden="true">
      <path
        d="M7.2 17.4 4.6 19.2c-.4.24-.9-.08-.86-.54l.22-2.5A7.4 7.4 0 1 1 12 19.2c-1.4 0-2.7-.36-3.8-.98l-.99.18Z"
        stroke="currentColor"
        strokeWidth="1.6"
      />
      <circle cx="9" cy="11.2" r="0.9" fill="currentColor" />
      <circle cx="12" cy="11.2" r="0.9" fill="currentColor" />
      <circle cx="15" cy="11.2" r="0.9" fill="currentColor" />
    </svg>
  );
}

function CloseIcon() {
  return (
    <svg width="20" height="20" viewBox="0 0 20 20" aria-hidden="true">
      <path d="M5 5.5 15 15.5M15 5.5 5 15.5" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" />
    </svg>
  );
}

function WhatsAppIcon() {
  return (
    <svg width="34" height="34" viewBox="0 0 34 34" aria-hidden="true">
      <path
        fill="currentColor"
        d="M17.1 4.2A12.3 12.3 0 0 0 6.6 22.3L5 29l6.9-1.5A12.3 12.3 0 1 0 17.1 4.2Zm0 22.4c-1.8 0-3.5-.5-5-1.4l-.4-.2-4.1.9.9-4-.2-.4a10.1 10.1 0 1 1 8.8 5.1Zm5.5-7.6c-.3-.15-1.75-.86-2-.96-.27-.1-.46-.15-.66.15-.2.3-.76.96-.93 1.16-.17.2-.34.22-.64.07-.3-.15-1.25-.46-2.38-1.46-.88-.78-1.47-1.74-1.64-2.04-.17-.3-.02-.46.13-.6.13-.14.3-.34.44-.52.15-.17.2-.3.3-.5.1-.2.05-.37-.02-.52-.08-.15-.66-1.58-.9-2.16-.24-.57-.48-.49-.66-.5h-.56c-.2 0-.52.07-.79.37-.27.3-1.04 1.02-1.04 2.48s1.07 2.88 1.22 3.08c.15.2 2.1 3.2 5.08 4.49.71.3 1.26.49 1.69.63.71.23 1.36.2 1.87.12.57-.08 1.75-.71 2-1.4.25-.69.25-1.28.17-1.4-.07-.13-.27-.2-.57-.35Z"
      />
    </svg>
  );
}

function FacebookIcon() {
  return (
    <svg width="28" height="28" viewBox="0 0 24 24" aria-hidden="true">
      <path
        fill="currentColor"
        d="M14.2 20.5v-7.1h2.4l.36-2.77h-2.76V8.86c0-.8.22-1.35 1.37-1.35h1.46V5.05A19 19 0 0 0 14.9 4.9c-2.1 0-3.55 1.28-3.55 3.64v2.08H8.8v2.77h2.55v7.1h2.85Z"
      />
    </svg>
  );
}
