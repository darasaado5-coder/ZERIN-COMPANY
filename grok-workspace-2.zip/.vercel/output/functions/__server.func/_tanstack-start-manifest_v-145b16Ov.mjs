//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-145b16Ov.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-DiKlIltB.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-DiKlIltB.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-3ovDTpMs.js"]
	}
} });
//#endregion
export { tsrStartManifest };
